package com.example.appchat

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
